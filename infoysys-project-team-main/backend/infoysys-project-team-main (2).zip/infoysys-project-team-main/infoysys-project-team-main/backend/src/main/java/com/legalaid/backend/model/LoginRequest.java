package com.legalaid.backend.model;

public class LoginRequest {
    private String email;
    private String password;

    // getters and setters
}
