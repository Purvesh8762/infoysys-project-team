@Autowired
private CustomUserDetailsService customUserDetailsService;

@Bean
public DaoAuthenticationProvider authProvider() {
    DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
    provider.setUserDetailsService(customUserDetailsService);
    provider.setPasswordEncoder(new BCryptPasswordEncoder());
    return provider;
}
