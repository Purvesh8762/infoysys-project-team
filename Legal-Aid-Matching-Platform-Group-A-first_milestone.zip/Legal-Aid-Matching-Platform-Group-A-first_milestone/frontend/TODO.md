# TODO: Redirect to Citizen Page After Sign-In

1. [x] Modify the `onLogin` function in `App.jsx` to always navigate to "/dashboard/citizen" with a success message, removing role-based logic.
2. [x] Remove the hardcoded `navigate` call in `Login.jsx`'s `handleSubmit` to avoid conflicts.
